'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { QuizAnswers, QuizQuestion } from '@/lib/types';
import QuizQuestionComponent from './QuizQuestion';
import ProgressBar from './ProgressBar';

const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 'genres',
    question: 'Jaki gatunek Cię interesuje?',
    subtitle: 'Możesz wybrać kilka',
    type: 'multiple',
    options: [
      { value: 'Komedia', label: 'Komedia', icon: '😄' },
      { value: 'Dramat', label: 'Dramat', icon: '🎭' },
      { value: 'Akcja', label: 'Akcja', icon: '💥' },
      { value: 'Horror', label: 'Horror', icon: '👻' },
      { value: 'Sci-Fi', label: 'Sci-Fi', icon: '🚀' },
      { value: 'Romans', label: 'Romans', icon: '💕' },
      { value: 'Thriller', label: 'Thriller', icon: '🔪' },
      { value: 'Animacja', label: 'Animacja', icon: '🎨' },
      { value: 'any', label: 'Wszystko jedno', icon: '🎲' },
    ],
  },
  {
    id: 'era',
    question: 'Nowszy czy starszy?',
    type: 'buttons',
    options: [
      { value: 'modern', label: 'Nowsze (2010+)', description: 'Nowoczesne produkcje' },
      { value: 'old', label: 'Starsze (przed 2000)', description: 'Klasyki kina' },
      { value: 'any', label: 'Wszystko jedno', description: 'Każda era ok' },
    ],
  },
  {
    id: 'origin',
    question: 'Polski czy zagraniczny?',
    type: 'buttons',
    options: [
      { value: 'polish', label: 'Polski', icon: '🇵🇱' },
      { value: 'foreign', label: 'Zagraniczny', icon: '🌍' },
      { value: 'any', label: 'Wszystko jedno', icon: '🎬' },
    ],
  },
  {
    id: 'pace',
    question: 'Jakie tempo?',
    type: 'buttons',
    options: [
      { value: 'slow', label: 'Spokojne', description: 'Powolna narracja' },
      { value: 'dynamic', label: 'Dynamiczne', description: 'Szybka akcja' },
      { value: 'any', label: 'Wszystko jedno', description: 'Każde tempo' },
    ],
  },
  {
    id: 'mood',
    question: 'Jaki klimat?',
    subtitle: 'Możesz wybrać kilka',
    type: 'multiple',
    options: [
      { value: 'light', label: 'Lekki', icon: '☀️' },
      { value: 'dark', label: 'Mroczny', icon: '🌙' },
      { value: 'emotional', label: 'Emocjonalny', icon: '😢' },
      { value: 'feelgood', label: 'Feel-good', icon: '😊' },
      { value: 'thoughtful', label: 'Do myślenia', icon: '🤔' },
      { value: 'tense', label: 'Napięcie', icon: '😰' },
    ],
  },
  {
    id: 'popularity',
    question: 'Popularny czy niszowy?',
    type: 'buttons',
    options: [
      { value: 'popular', label: 'Popularny', description: 'Znane produkcje' },
      { value: 'niche', label: 'Niszowy', description: 'Ukryte perełki' },
      { value: 'any', label: 'Wszystko jedno', description: 'Nie ma znaczenia' },
    ],
  },
  {
    id: 'runtime',
    question: 'Jak długi?',
    type: 'buttons',
    options: [
      { value: 'short', label: 'Krótki', description: 'Do 100 min' },
      { value: 'medium', label: 'Średni', description: '90-130 min' },
      { value: 'long', label: 'Długi', description: 'Ponad 130 min' },
      { value: 'any', label: 'Wszystko jedno', description: 'Każda długość' },
    ],
  },
];

interface QuizProps {
  onComplete: (answers: QuizAnswers) => void;
}

export default function Quiz({ onComplete }: QuizProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Partial<QuizAnswers>>({
    genres: [],
    mood: [],
  });

  const currentQuestion = QUIZ_QUESTIONS[currentStep];
  const isLastQuestion = currentStep === QUIZ_QUESTIONS.length - 1;
  const progress = ((currentStep + 1) / QUIZ_QUESTIONS.length) * 100;

  const handleAnswer = (value: string | string[]) => {
    const newAnswers = {
      ...answers,
      [currentQuestion.id]: value,
    };
    setAnswers(newAnswers);

    // Auto-przejście dla single choice
    if (currentQuestion.type === 'buttons' || currentQuestion.type === 'single') {
      setTimeout(() => {
        if (isLastQuestion) {
          onComplete(newAnswers as QuizAnswers);
        } else {
          setCurrentStep(currentStep + 1);
        }
      }, 300);
    }
  };

  const handleNext = () => {
    if (isLastQuestion) {
      onComplete(answers as QuizAnswers);
    } else {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const canProceed = () => {
    const answer = answers[currentQuestion.id];
    if (!answer) return false;
    if (Array.isArray(answer)) return answer.length > 0;
    return true;
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4">
      <ProgressBar progress={progress} currentStep={currentStep + 1} totalSteps={QUIZ_QUESTIONS.length} />
      
      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.3 }}
          className="mt-12"
        >
          <QuizQuestionComponent
            question={currentQuestion}
            value={answers[currentQuestion.id]}
            onChange={handleAnswer}
          />
          
          {currentQuestion.type === 'multiple' && (
            <div className="flex gap-4 mt-8">
              {currentStep > 0 && (
                <button
                  onClick={handleBack}
                  className="px-6 py-3 rounded-xl border-2 border-gray-300 hover:border-gray-400 
                           transition-all duration-200 font-medium text-gray-700"
                >
                  Wstecz
                </button>
              )}
              <button
                onClick={handleNext}
                disabled={!canProceed()}
                className="flex-1 px-6 py-3 rounded-xl bg-gradient-to-r from-primary-500 to-primary-600 
                         text-white font-medium hover:from-primary-600 hover:to-primary-700
                         disabled:from-gray-300 disabled:to-gray-400 disabled:cursor-not-allowed
                         transition-all duration-200 shadow-lg hover:shadow-xl"
              >
                {isLastQuestion ? 'Znajdź film' : 'Dalej'}
              </button>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
