import { NextRequest, NextResponse } from 'next/server';
import { getRecommendation, getRandomRecommendation } from '@/lib/recommendation-engine';
import { QuizAnswers } from '@/lib/types';

/**
 * POST /api/recommend
 * Zwraca rekomendację filmu na podstawie odpowiedzi z quizu
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { answers, excludeIds = [], random = false } = body;

    if (!answers && !random) {
      return NextResponse.json(
        { error: 'Missing quiz answers' },
        { status: 400 }
      );
    }

    let recommendation;

    if (random) {
      // Tryb losowy - całkowicie losowa rekomendacja
      const movie = getRandomRecommendation(excludeIds);
      if (!movie) {
        return NextResponse.json(
          { error: 'No movies found' },
          { status: 404 }
        );
      }
      recommendation = {
        movie,
        score: 0,
        reasons: ['Losowy wybór']
      };
    } else {
      // Normalny tryb - rekomendacja na podstawie odpowiedzi
      recommendation = getRecommendation(answers as QuizAnswers, excludeIds);
      
      if (!recommendation) {
        return NextResponse.json(
          { error: 'No matching movies found. Try adjusting your preferences.' },
          { status: 404 }
        );
      }
    }

    return NextResponse.json({
      movie: recommendation.movie,
      reasons: recommendation.reasons,
      score: recommendation.score
    });

  } catch (error) {
    console.error('Recommendation error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
