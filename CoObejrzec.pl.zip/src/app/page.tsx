'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Quiz from '@/components/Quiz/Quiz';
import MovieCard from '@/components/MovieCard/MovieCard';
import WatchLaterList from '@/components/WatchLater/WatchLaterList';
import { useSessionStore } from '@/store/session-store';
import { Movie, QuizAnswers } from '@/lib/types';

type AppState = 'welcome' | 'quiz' | 'recommendation';

export default function Home() {
  const [appState, setAppState] = useState<AppState>('welcome');
  const [currentMovie, setCurrentMovie] = useState<Movie | null>(null);
  const [reasons, setReasons] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const {
    quizAnswers,
    setQuizAnswers,
    rejectedMovies,
    rejectMovie,
    addToWatchLater,
    recommendationCount,
    resetSession,
  } = useSessionStore();

  const MAX_RECOMMENDATIONS = 10;
  const remainingRecommendations = MAX_RECOMMENDATIONS - recommendationCount;

  const fetchRecommendation = async (random = false) => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          answers: quizAnswers,
          excludeIds: rejectedMovies,
          random
        }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || 'Nie udało się znaleźć filmu');
      }

      const data = await response.json();
      setCurrentMovie(data.movie);
      setReasons(data.reasons || []);
      setAppState('recommendation');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Wystąpił błąd');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuizComplete = (answers: QuizAnswers) => {
    setQuizAnswers(answers);
    fetchRecommendation();
  };

  const handleReject = () => {
    if (remainingRecommendations <= 1 || !currentMovie) {
      setAppState('welcome');
      resetSession();
      setCurrentMovie(null);
      return;
    }
    rejectMovie(currentMovie.id);
    fetchRecommendation();
  };

  const handleAccept = () => {
    if (currentMovie) {
      addToWatchLater(currentMovie);
      rejectMovie(currentMovie.id); // Dodajemy do odrzuconych, żeby nie pokazać go w tej samej sesji ponownie
    }
    
    if (remainingRecommendations <= 1) {
      setAppState('welcome');
      resetSession();
      setCurrentMovie(null);
      return;
    }
    fetchRecommendation();
  };

  const handleRandom = () => {
    if (currentMovie) {
      rejectMovie(currentMovie.id);
    }
    fetchRecommendation(true);
  };

  const handleStartOver = () => {
    resetSession();
    setCurrentMovie(null);
    setAppState('quiz');
  };

  return (
    <div className="container mx-auto px-4 py-8 md:py-16">
      <AnimatePresence mode="wait">
        {/* Welcome Screen */}
        {appState === 'welcome' && (
          <motion.div
            key="welcome"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="max-w-3xl mx-auto text-center"
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-sm font-bold tracking-widest text-indigo-600 uppercase bg-indigo-50 rounded-full">
              Szybki dobór filmu 2026
            </span>
            <h2 className="text-4xl md:text-6xl font-black text-slate-900 mb-6 leading-tight">
              Skończ z nudą. <br />
              Znajdź film w <span className="text-indigo-600 underline">30 sekund</span>.
            </h2>
            <p className="text-xl text-slate-500 mb-10 max-w-xl mx-auto">
              Nasz algorytm dopasuje film do Twojego nastroju, platformy streamingowej i tego, z kim dziś oglądasz.
            </p>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setAppState('quiz')}
              className="px-10 py-5 bg-indigo-600 text-white text-xl font-bold rounded-2xl shadow-xl shadow-indigo-200 hover:bg-indigo-700 transition-all mb-12"
            >
              Zacznij darmowy quiz
            </motion.button>

            {/* AdSense Placement - Widoczny pod przyciskiem Start */}
            <div className="w-full h-32 bg-slate-50 border border-dashed border-slate-200 rounded-xl flex items-center justify-center text-slate-400 text-sm mb-12">
              Reklama (Główna)
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                { icon: '🎬', title: '15,000+ Filmów', desc: 'Największa baza rekomendacji' },
                { icon: '🤖', title: 'Smart Match', desc: 'Algorytm oparty na vibe' },
                { icon: '🍿', title: 'Zero logowania', desc: 'Wchodzisz i wybierasz' },
              ].map((feature, i) => (
                <div key={i} className="p-6 bg-white rounded-2xl shadow-sm border border-slate-100">
                  <div className="text-3xl mb-3">{feature.icon}</div>
                  <h3 className="font-bold text-slate-900">{feature.title}</h3>
                  <p className="text-sm text-slate-500">{feature.desc}</p>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Quiz */}
        {appState === 'quiz' && (
          <motion.div
            key="quiz"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="max-w-2xl mx-auto"
          >
            <div className="mb-8 flex justify-between items-center">
              <button onClick={() => setAppState('welcome')} className="text-slate-400 hover:text-indigo-600 font-medium">
                ← Powrót
              </button>
              <div className="text-slate-400 text-sm font-bold uppercase tracking-widest">Krok 1 z 7</div>
            </div>
            <Quiz onComplete={handleQuizComplete} />
          </motion.div>
        )}

        {/* Recommendation */}
        {appState === 'recommendation' && (
          <motion.div
            key="recommendation"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-20">
                <div className="relative">
                  <div className="w-20 h-20 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin"></div>
                  <div className="absolute inset-0 flex items-center justify-center text-2xl">🎬</div>
                </div>
                <p className="mt-6 text-xl font-bold text-slate-900">Analizujemy Twoje odpowiedzi...</p>
                <p className="text-slate-500">Przeszukujemy bazę 15,000 filmów</p>
              </div>
            ) : error ? (
              <div className="max-w-md mx-auto text-center py-20 bg-white rounded-3xl shadow-sm border border-slate-100">
                <div className="text-6xl mb-6">🏜️</div>
                <h3 className="text-2xl font-black text-slate-900 mb-2">Brak wyników</h3>
                <p className="text-slate-500 mb-8 px-6">{error}</p>
                <button
                  onClick={handleStartOver}
                  className="px-8 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all"
                >
                  Zmień preferencje
                </button>
              </div>
            ) : currentMovie ? (
              <div className="max-w-5xl mx-auto">
                <MovieCard
                  movie={currentMovie}
                  reasons={reasons}
                  onReject={handleReject}
                  onAccept={handleAccept}
                  onRandom={handleRandom}
                  remainingRecommendations={remainingRecommendations}
                />
                
                {/* AdSense Placement - Pod kartą filmu */}
                <div className="mt-12 w-full h-24 bg-slate-50 border border-dashed border-slate-200 rounded-xl flex items-center justify-center text-slate-400 text-sm">
                  Reklama (Pod wynikiem)
                </div>
              </div>
            ) : null}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Watch Later Section */}
      <div id="watch-later" className="mt-32">
        <WatchLaterList />
      </div>
    </div>
  );
}